#include <system.h>                   // system functions
#include <gpio.h>                     // GPIO functions

#define PIN_LED1 PA4                  // define LED1 pin
#define PIN_LED2 PA5                  // define LED2 pin
#define PIN_LED3 PA6                  // define LED3 pin

#define PIN_SW1 PA0                   // define Switch1 pin
#define PIN_SW2 PA1                   // define Switch2 pin

#define PIN_TEMT6k PB1                // define TEMT6k Analog pin

// Main Function
int main(void) {
  // Setup
  // PIN_output(PIN_LED1);               // set LED pin to output
  // PIN_output(PIN_LED2);               // set LED pin to output
  PIN_output(PIN_LED3);               // set LED pin to output

  // PIN_input_PU(PIN_SW1);							// set Swtich pin to input
  // PIN_input_PU(PIN_SW2);							// set Swtich pin to input

  // PIN_input_AN(PIN_TEMT6k);           // set Swtich pin to input

  // Loop
  while(1) {
   // PIN_write(PIN_LED1, PIN_read(PIN_SW1));   // write LED PIN output with Touch value
   // PIN_write(PIN_LED2, PIN_read(PIN_SW2));   // write LED PIN output with Touch value

    PIN_toggle(PIN_LED3);             // toggle LED3
    DLY_ms(150);                      // wait 140ms
  }
}
